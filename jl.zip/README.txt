Hi,
Here's the need to know things:
Remeber to add this in your ACL.xml, group Admin
<object name="resource.jl" />
and
<right name="function.callRemote" access="true" />

If you want to enable a background picture edit the meta.xml and change the value of the name.
Same if you want to change the image.

By:Jaysds1
http://www.jquonprojects.tk