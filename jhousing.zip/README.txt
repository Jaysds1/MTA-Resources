JHousing System Version 1

This Housing system features:
-Buying a House
-Touring a House
-Being a Guest of the House
-Selling a House

House Data:
-House Name
-House Price
-House Interior
-House Dimension

The command for creating a house: "/createHouse"

Please report a bug/suggestiong you find/want either:
- on Community Site: http://community.mtasa.com/index.php?p=resources&s=details&id=5525
- on MTA Forum: http://forum.mtasa.com/memberlist.php?mode=viewprofile&u=56218&sid=ed601c6b83a1de823229eb4c7b3869dd
- or on JW137 Bugs: http://bugs.jworld137.site11.com/