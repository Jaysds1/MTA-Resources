local players = {}
local url,ssSet,n = "http://mtasa-community.jworld137.com/player.php","@community_statistic.SS",getServerName()
local ss = tostring(get(ssSet)) or ""

function result(inputs,ret)
	if inputs=="ERROR" then outputDebugString("Problem connecting to JWorld137! Please restart the resource!",1) end
	if inputs[2]=="server" then
		ss = inputs[1]
		set(ssSet,ss)
	elseif inputs[2]=="check" then
		--[[
			inputs:
				2 = serial
				3 = name
		]]
		if ret==0 then
			callRemote(url,result,ss,"add",inputs[3],inputs[4])
		end
	elseif inputs[2]=="add" then
		--[[
			inputs:
				2 = serial
				3 = name
		]]
		if ret==0 then
			outputDebugString("Community Statistic - Unable to add!",1)
		end
	elseif inputs[2]=="update" then
		--[[
			inputs:
				2 = type of update
				3 = serial
		]]
		if ret==0 then
			outputDebugString("Community Statistic - Unable to update!",1)
		end
	end
end
callRemote(url,result,ss,"server",n)
setTimer(function()
	--Loop through all the players
	for _,p in ipairs(getElementsByType("player"))do
		local s,n,ip = getPlayerSerial(p),getPlayerName(p),getPlayerIP(p)
		--checkPlayer(s,n)
		players[p] = { s, n, ip }
		callRemote(url,result,ss,"check",s,n,ip)
	end
end,3000,1)
addEventHandler("onPlayerJoin",root,function()
	outputDebugString(source)
	local s,n,ip = getPlayerSerial(source),getPlayerName(source),getPlayerIP(source)
	--checkPlayer(s,n)
	players[source] = { s, n, ip }
	callRemote(url,result,ss,"check",s,n,ip)
end)
addEventHandler("onPlayerQuit",root,function()
	players[source] = nil
end)

--Events and Updates
addEventHandler("onPlayerWasted",root,function(k)
	if k and getElementType(k)=="player" and k~=source then
		callRemote(url,result,ss,"update","kill",players[k][1],players[k][2],players[k][3])
	end
	setTimer(function(source)
		callRemote(url,result,ss,"update","death",players[source][1],players[source][2],players[source][3])
	end,3000,1,source)
end)