Hi,
This is joinquitj version 3,
we have added DX and Labels, with colors, so everything is easy :D

anyways, to use the meta.xml settings, remove the '--[[ <--REMOVE THESE TO ENABLE IT' and 'AND THESE--> ]]'.

that's all :D
have a nice day and good luck with your server.

By:Jaysds1
http://www.jworld137.tk