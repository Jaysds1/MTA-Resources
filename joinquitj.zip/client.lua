local screenWidth, screenHeight = guiGetScreenSize()

local width = 300
local height = 300

local left = screenWidth/10.7 - width/2
local top = screenHeight/3 - height/2

local isNormal = true
local isJoin = true


addEventHandler("onClientResourceStart",resourceRoot,function(res)
	if res==getThisResource() then
		triggerServerEvent("JW.Service",root,"ready")
		addEventHandler("onClientRender",root,showDX)
	end
end)

--DX
local joinName = false
local loginName = false
local quitName = false
function showDX()
	if joinName then
		dxDrawText("Joined: "..joinName,left,top,width,height,tocolor(0,100,0),1.3)
	end
	if loginName then
		dxDrawText("Logged-In: "..loginName,left,top,width,height,tocolor(0,100,0),1.3)
	end
	if quitName then
		dxDrawText("Quit: "..quitName,left,top+100,width,height,tocolor(100,0,0),1.3)
	end
end

addCommandHandler("t",function()
	local tst = guiCreateLabel(left,top,width,height,"Test: "..getPlayerName(localPlayer),false)
	setTimer(destroyElement,7000,1,tst)
end)

addEventHandler("onClientPlayerJoin",root,function()
	if isJoin then
		local name = getPlayerName(source)
		if isNormal then
			if isElement(jon) then
				resetTimer(pn)
				guiSetText(jon,"Joined: "..name)
			else
				local jon = guiCreateLabel(left,top,width,height,"Joined: "..name,false)
				guiLabelSetColor(jon,0,100,0)
				local pn = setTimer(destroyElement,7000,1,jon)
			end
		else
			joinName = name
			setTimer(function()
				name = false
			end,7000,1)
		end
	end
end)

addEvent("login",true)
addEventHandler("login",root,function(name)
	if not isJoin or isJoin==false then
		if isNormal then
			if isElement(log) then
				resetTimer(pn)
				guiSetText(log,"Logged-In: "..name)
			else
				local log = guiCreateLabel(left,top,width,height,"Logged-In: "..name,false)
				guiLabelSetColor(log,0,100,0)
				local pn = setTimer(destroyElement,7000,1,log)
			end
		else
			loginName = name
			setTimer(function()
				loginName = false
			end,7000,1)
		end
	end
end)

addEventHandler("onClientPlayerQuit",root,function(reason)
	local name = getPlayerName(source)
	if isNormal then
		if isElement(lev)then
			resetTimer(lv)
			guiSetText(lev,"Left: "..name.."["..reason.."]")
		else
			local lev = guiCreateLabel(left,top+100,width,height,"Left: "..name.."["..reason.."]",false)
			guiLabelSetColor(lev,100,0,0)
			local lv = setTimer(destroyElement,7000,1,lev)
		end
	else
		quitName = name
		setTimer(function()
			quitName = false
		end,7000,1)
	end
end)

--Checking
addEvent("JW.Service",true)
addEventHandler("JW.Service",root,function(guityp,typ)
	isNormal = guityp
	isJoin = typ
end)