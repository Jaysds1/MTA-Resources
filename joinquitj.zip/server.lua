addEventHandler("onPlayerLogin",root,function()triggerClientEvent("login",root,source.name)end)addEvent("JW.Service",true)addEventHandler("JW.Service",root,function(a)end)
